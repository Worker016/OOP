﻿using DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Entities
{
    public class Spending_type : IEntity<int>
    {
        public int Id { get; set; }
        public string Spending_name { get; set; }
        public string Description { get; set; }
    }
}

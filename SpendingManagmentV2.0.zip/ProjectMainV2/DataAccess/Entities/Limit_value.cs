﻿using DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Entities
{
    public class Limit_value :IEntity<int>
    {
        public int Id { get; set; }
        public int Id_Dep { get; set; }
        public int Id_Spend_type { get; set; }
        public int Limit_value_in_order { get; set; }
    }
}

﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.Entities
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {

        }
        public DbSet<Spending> Spendings { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)//fluent validation
        {
            base.OnModelCreating(modelBuilder);
            #region Spending
            modelBuilder.Entity<Spending>()
                .Property(p => p.Id)
                .IsRequired();
            modelBuilder.Entity<Spending>()
                .HasKey(x => x.Id);
            modelBuilder.Entity<Spending>()
                .Property(p => p.Id_Dep)
                .IsRequired();
            modelBuilder.Entity<Spending>()
                .Property(p => p.Id_Spend_type)
                .IsRequired();
            modelBuilder.Entity<Spending>()
                .Property(p => p.Summa)
                .IsRequired();
            //modelBuilder.Entity<Spending>(builder => 
            //{
            //    builder.Property(p => p.DateT).HasDefaultValueSql("getdate()");
            //});

                #endregion
            }
        
        public DbSet<Department> Departments { get; set; }
        public DbSet<Spending_type> Spending_Types { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Limit_value> limit_Values { get; set; }
    }
}

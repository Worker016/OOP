﻿using DataAccess.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Entities
{
    public class Department : IEntity<int>
    {
        public int Id { get; set; }
        public string Depart_name { get; set; }
        public int Employee_count { get; set; }
    }
}

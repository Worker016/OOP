﻿using System.Linq;
using System.Threading.Tasks;
using DataAccess.Interfaces;
using DataAccessLayer.Entities;
using DataAccessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DataAccessLayer.Repositories
{
    public class GenericRepository<TEntity, TId> : IGenericRepository<TEntity, TId> where TEntity : class, IEntity<TId>
    {
        private readonly MyDbContext _context;

        public GenericRepository(MyDbContext context)
        {
            _context = context;
        }
        public IQueryable<TEntity>  GetAll()
        {
            return _context.Set<TEntity>().AsNoTracking();
        }
        public async Task<TEntity> Get(TId id)
        {
            //return await _context.Set<TEntity>()
            //            .AsNoTracking()
            //            .FirstOrDefaultAsync(e => e.Id == id);

            //                  return _context.Set<TEntity>().Find(id);
            return await _context.Set<TEntity>().FindAsync(id);
        }
        public async Task Add(TEntity entity)
        {
            await _context.Set<TEntity>().AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task Update(TEntity entity)
        {
            _context.Set<TEntity>().Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(TId id)
        {
            var entity = await Get(id);
            _context.Set<TEntity>().Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}

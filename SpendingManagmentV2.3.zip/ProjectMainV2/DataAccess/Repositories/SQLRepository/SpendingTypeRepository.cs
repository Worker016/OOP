﻿using DataAccess.Interfaces.RepositoriesInterfaces;
using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.Repositories.SQLRepository
{
    public class SpendingTypeRepository : GenericRepository<Spending_type, int>, ISpendingTypeRepository
    {
        public SpendingTypeRepository(MyDbContext myDbContext) : base(myDbContext) { }
    }
}
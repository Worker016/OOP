﻿using DataAccess.Interfaces.RepositoriesInterfaces;
using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.Repositories.SQLRepository
{
    public class LimitValueRepository : GenericRepository<Limit_value, int>, ILimitValueRepository
    {
        public LimitValueRepository(MyDbContext myDbContext) : base(myDbContext) { }
    }
}
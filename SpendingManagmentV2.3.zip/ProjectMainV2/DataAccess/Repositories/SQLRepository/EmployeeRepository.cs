﻿using DataAccess.Interfaces.RepositoriesInterfaces;
using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.Repositories.SQLRepository
{
    public class EmployeeRepository : GenericRepository<Employee, int>, IEmployeeRepository
    {
        public EmployeeRepository(MyDbContext myDbContext) : base(myDbContext) { }
    }
}
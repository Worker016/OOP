﻿using DataAccess.Interfaces.RepositoriesInterfaces;
using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.Repositories.SQLRepository
{
    public class SpendingRepository : GenericRepository<Spending,int>, ISpendingRepository
    { 
        public SpendingRepository(MyDbContext myDbContext): base(myDbContext) { }
    }
}
﻿using DataAccess.Interfaces.RepositoriesInterfaces;
using DataAccessLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    class UnitOfWork : IUnitOfWork
    {
        private readonly ISpendingRepository _spendingRepository;
        private readonly IDepartmentRepository _departmentRepository;
        private readonly ISpendingTypeRepository _spendingTypeRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILimitValueRepository _limitValueRepository;
        public UnitOfWork(ISpendingRepository spendingRepository,
            IDepartmentRepository departmentRepository,
            ISpendingTypeRepository spendingTypeRepository,
            IEmployeeRepository employeeRepository,
            ILimitValueRepository limitValueRepository)
        {
            _spendingRepository = spendingRepository;
            _departmentRepository = departmentRepository;
            _spendingTypeRepository = spendingTypeRepository;
            _employeeRepository = employeeRepository;
            _limitValueRepository = limitValueRepository;
        }
        public ISpendingRepository SpendingRepository
        {
            get
            {
                return _spendingRepository;
            }
        }
        public IDepartmentRepository DepartmentRepository
        {
            get
            {
                return _departmentRepository;
            }
        }
        public ISpendingTypeRepository SpendingTypeRepository
        {
            get
            {
                return _spendingTypeRepository;
            }
        }
        public IEmployeeRepository EmployeeRepository
        {
            get
            {
                return _employeeRepository;
            }
        }
        public ILimitValueRepository LimitValueRepository
        {
            get
            {
                return _limitValueRepository;
            }
        }
        public void Complete()
        {
            throw new NotImplementedException();
        }
    }
}

﻿using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Interfaces.RepositoriesInterfaces
{
    public interface IEmployeeRepository : IGenericRepository<Employee, int>
    {
    }
}

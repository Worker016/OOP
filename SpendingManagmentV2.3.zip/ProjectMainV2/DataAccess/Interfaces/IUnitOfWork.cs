﻿using DataAccess.Interfaces.RepositoriesInterfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer.Interfaces
{
    public interface IUnitOfWork 
    {
        ISpendingRepository SpendingRepository { get; }
        IDepartmentRepository DepartmentRepository { get; }
        ISpendingTypeRepository SpendingTypeRepository { get; }
        IEmployeeRepository EmployeeRepository { get; }
        ILimitValueRepository LimitValueRepository { get; }
        void Complete();
    }
}

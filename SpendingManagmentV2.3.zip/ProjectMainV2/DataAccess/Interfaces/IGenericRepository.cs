﻿using DataAccessLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Interfaces
{
    public interface IGenericRepository<TEntity, TId> where TEntity : IEntity<TId>
    {
        IQueryable<TEntity> GetAll();
        Task<TEntity> Get(TId Id);
        Task Add(TEntity entity);
        Task Update(TEntity entity);
        Task Delete(TId Id);
    }
}

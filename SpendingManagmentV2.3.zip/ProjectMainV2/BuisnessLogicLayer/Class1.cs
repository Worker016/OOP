﻿using System;

namespace BuisnessLogicLayer
{
    public class Class1
    {
    }
}

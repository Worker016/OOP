﻿using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Interfaces.RepositoriesInterfaces
{
    interface IDepartmentRepository : IGenericRepository<Department, int>
    {
    }
}

﻿using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Interfaces.RepositoriesInterfaces
{
    public interface ISpendingRepository : IGenericRepository<Spending, int>
    {
    }
}

﻿CREATE PROCEDURE UpPayForAllInDepartment
@which_one int
AS
UPDATE Emploee
SET Salary=Salary+Salary*0.15 where [Id_Dep] = @which_one

﻿CREATE FUNCTION CHECKSUMM
(
	@a INT,
	@b INT
)
RETURNS INT
AS
BEGIN
DECLARE @сума INT
SET @сума=(	SELECT TOP(1) [Limit_value_in_order]
			FROM Limit_value
			WHERE Limit_value.Id_Dep=@a AND Limit_value.Id_Spend_type=@b)
RETURN @сума
END

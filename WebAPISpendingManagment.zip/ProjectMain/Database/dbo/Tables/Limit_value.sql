﻿CREATE TABLE [dbo].[Limit_value] (
    [Id]                   INT NOT NULL,
    [Id_Dep]               INT NOT NULL,
    [Id_Spend_type]        INT NOT NULL,
    [Limit_value_in_order] INT NOT NULL,
    CONSTRAINT [FK__Limit_val__Id_De__3F466844] FOREIGN KEY ([Id_Dep]) REFERENCES [dbo].[Department] ([Id]),
    CONSTRAINT [FK__Limit_val__Id_Sp__403A8C7D] FOREIGN KEY ([Id_Spend_type]) REFERENCES [dbo].[Spending_type] ([Id]),
    UNIQUE NONCLUSTERED ([Id_Dep] ASC, [Id_Spend_type] ASC)
);


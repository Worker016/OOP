﻿CREATE TABLE [dbo].[Spending] (
    [Id]            INT  IDENTITY (1, 1) NOT NULL,
    [Id_Dep]        INT  NOT NULL,
    [Id_Spend_type] INT  NOT NULL,
    [DateT]         DATE CONSTRAINT [DF__Spending__DateT__44FF419A] DEFAULT (CONVERT([date],getdate())) NULL,
    [Summa]         INT  NOT NULL,
    CONSTRAINT [PK__Spending__3214EC07539EC110] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [CK__Spending__46E78A0C] CHECK ([Summa]<=[dbo].[CHECKSUMM]([Spending].[Id_Dep],[Spending].[Id_Spend_type])),
    CONSTRAINT [CK__Spending__DateT__45F365D3] CHECK ([DateT]<=CONVERT([date],getdate())),
    CONSTRAINT [FK__Spending__Id_Dep__3B75D760] FOREIGN KEY ([Id_Dep]) REFERENCES [dbo].[Department] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK__Spending__Id_Spe__3C69FB99] FOREIGN KEY ([Id_Spend_type]) REFERENCES [dbo].[Spending_type] ([Id]) ON DELETE CASCADE
);


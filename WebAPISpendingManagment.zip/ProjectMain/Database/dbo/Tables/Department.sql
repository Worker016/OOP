﻿CREATE TABLE [dbo].[Department] (
    [Id]             INT        IDENTITY (1, 1) NOT NULL,
    [Depart_name]    NCHAR (45) NOT NULL,
    [Employee_count] INT        NOT NULL,
    CONSTRAINT [PK__Departme__3214EC07CB85EB1D] PRIMARY KEY CLUSTERED ([Id] ASC)
);


﻿CREATE TABLE [dbo].[Emploee] (
    [Id]       INT        IDENTITY (1, 1) NOT NULL,
    [Name]     NCHAR (45) NOT NULL,
    [SurName]  NCHAR (45) NOT NULL,
    [LastName] NCHAR (45) NOT NULL,
    [Id_Dep]   INT        NOT NULL,
    [Salary]   INT        NOT NULL,
    CONSTRAINT [PK__Emploee__3214EC072D75C9ED] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK__Emploee__Id_Dep__4316F928] FOREIGN KEY ([Id_Dep]) REFERENCES [dbo].[Department] ([Id])
);


﻿CREATE TABLE [dbo].[Spending_type] (
    [Id]            INT         IDENTITY (1, 1) NOT NULL,
    [Spending_name] NCHAR (45)  NOT NULL,
    [Description]   NCHAR (100) NULL,
    CONSTRAINT [PK__Spending__3214EC076DA01B62] PRIMARY KEY CLUSTERED ([Id] ASC)
);


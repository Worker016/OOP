﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLRepositories;
using DataAccessLayer.Enteties;
using DataAccessLayer.Interfaceses;

namespace DataAccessLayer.Repositories.SQLRepositories
{
    public class SQLDepartmentRepository : GenericRepository<Department, int>, ISQLDepartmentRepository
    {
        private static readonly string _tableName = "Department";
        private static readonly bool _isSoftDelete = true;
        public SQLDepartmentRepository(IConnectionFactory connectionFactory) : base(connectionFactory, _tableName, _isSoftDelete)
        {
            connectionFactory.SetConnection(DefaultConnection.x);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLRepositories;
using DataAccessLayer.Enteties;
using DataAccessLayer.Interfaceses;
using System.Configuration;
using DataAccessLayer;

namespace DataAccessLayer.Repositories.SQLRepositories
{
    public class SQLSpendingRepository : GenericRepository<Spending,int>, ISQLSpendingRepository
    {
        private static readonly string _tableName = "Spending";
        private static readonly bool _isSoftDelete = true;
        public SQLSpendingRepository(IConnectionFactory connectionFactory /*, bool IsTest*/) : base(connectionFactory, _tableName, _isSoftDelete)
        {
            /*if (!IsTest)*/
            connectionFactory.SetConnection(DefaultConnection.x);
            //ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
        }
    }
}

﻿using System;
using Dapper;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses;
using DataAccessLayer.Interfaceses.EntityInterfaces;
using System.Linq;
using System.Reflection;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLayer.Repositories
{
    public class GenericRepository<TEntity, TId> : IGenericRepository<TEntity, TId> where TEntity : IEntity<TId>
    {
        protected IConnectionFactory _connectionFactory;
        private readonly string _tableName;
        private readonly bool _isSoftDelete;
        public GenericRepository(IConnectionFactory connectionFactory, string tableName, bool isSoftDelete)
        {
            _connectionFactory = connectionFactory;
            _tableName = tableName;
            _isSoftDelete = isSoftDelete;
        }
        public int Add(TEntity entity)
        {
            var columns = GetColumns();
            var stringOfColumns = string.Join(", ", columns);
            var query = "SP_InsertRecordToTable";
            List<string> listOfProperties = new List<string>();
            foreach (var col in columns)
            {
                var t = typeof(TEntity).GetProperty(col);
                string x;
                if (t.PropertyType == typeof(string))
                    x = $"'{t.GetValue(entity)}'";
                else
                {
                    x = $"{t.GetValue(entity)}";
                    if (t.PropertyType == typeof(DateTime))
                    {
                        x = $"'{t.GetValue(entity)}'";
                        x = x.Remove(10, 8);
                        x = x.Replace('.', '/');
                    }
                }
                
                listOfProperties.Add(x);
            }
            string stringOfProperties = string.Join(", ", listOfProperties);
            using (var db = _connectionFactory.GetSqlConnection)
            {
                SqlCommand sqlCommand = new SqlCommand(query, (SqlConnection)db);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.Add(new SqlParameter("@P_tableName", _tableName));
                sqlCommand.Parameters.Add(new SqlParameter("@P_columnsString", stringOfColumns));
                sqlCommand.Parameters.Add(new SqlParameter("@P_propertiesString", stringOfProperties));
                int InsertedEntityId = (int)sqlCommand.ExecuteScalar();
                return InsertedEntityId;
            }
        }

        public void Update(TEntity entity)
        {
            var columns = GetColumns();
            List<string> listOfColumns = new List<string>();
            foreach (var col in columns)
            {
                var t = typeof(TEntity).GetProperty(col);
                string x;
                if (t.PropertyType == typeof(string))
                    x = $"{col} = '{t.GetValue(entity)}'";
                else
                {
                    x = $"{col} = {t.GetValue(entity)}";
                }
                if(t.PropertyType == typeof(DateTime))
                {
                    x = $"{col}='{t.GetValue(entity)}'";
                    x = x.Remove(17,8);
                }
                listOfColumns.Add(x);
            }
            string stringOfColumns = string.Join(", ", listOfColumns);
            using (var db = _connectionFactory.GetSqlConnection)
            {
                var query = "SP_UpdateRecordInTable";
                SqlCommand sqlCommand = new SqlCommand(query, (SqlConnection)db);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.Add(new SqlParameter("@P_tableName", _tableName));
                sqlCommand.Parameters.Add(new SqlParameter("@P_columnsString", stringOfColumns));
                sqlCommand.Parameters.Add(new SqlParameter("@P_Id", entity.Id));
                sqlCommand.ExecuteNonQuery();
            }
        }

        public void Delete(TId id)
        {
                using (var db = _connectionFactory.GetSqlConnection)
                {
                    var query = "SP_DeleteRecordFromTable";
                    var result = db.Execute(
                        sql: query,
                        param: new { P_tableName = _tableName, P_Id = id },
                        commandType: CommandType.StoredProcedure);
                }
        }

        public TEntity Get(TId Id)
        {
            var query = "SP_GetRecordByIdFromTable";

            using (var db = _connectionFactory.GetSqlConnection)
            {
                return db.Query<TEntity>(query,
                    new { P_tableName = _tableName, P_Id = Id },
                    commandType: CommandType.StoredProcedure).FirstOrDefault();
            }
        }

        public IEnumerable<TEntity> GetAll()
        {
            var query = "SP_GetAllRecordsFromTable";

            using (var db = _connectionFactory.GetSqlConnection)
            {
                return db.Query<TEntity>(query,
                    new { P_tableName = _tableName },
                    commandType: CommandType.StoredProcedure);
            }
        }

        private IEnumerable<string> GetColumns()
        {
            return typeof(TEntity)
                    .GetProperties()
                    .Where(e => e.Name != "Id" && !e.PropertyType.GetTypeInfo().IsGenericType)
                    .Select(e => e.Name);
        }
    }
}

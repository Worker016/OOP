﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer.Ifrastructure
{
    public class ConnectionFactory : IConnectionFactory
    {
        private static string _connectionstring;
        public void SetConnection(string connectionstring)
        {
            _connectionstring = connectionstring;
        }
        public IDbConnection GetSqlConnection
        {
            get
            {
                SqlConnection connection;
                if (!string.IsNullOrEmpty(_connectionstring))
                {
                    connection = new SqlConnection(_connectionstring);
                }
                else
                {
                    connection = new SqlConnection(DefaultConnection.x);
//                    connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
                }
                connection.Open();
                return connection;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses.EntityInterfaces;
namespace DataAccessLayer.Enteties
{
    public class Spending : IEntity<int>
    {
        public int Id { get; set; }
        public int Id_Dep { get; set; }
        public int Id_Spend_type { get; set; }
        public DateTime DateT { get; set; }
        public int Summa { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses.EntityInterfaces;
namespace DataAccessLayer.Interfaceses
{
    public interface IGenericRepository<TEntity, TId> where TEntity : IEntity<TId>
    {
        IEnumerable<TEntity> GetAll();
        TEntity Get(TId Id);
        int Add(TEntity entity);
        void Update(TEntity entity);
        void Delete(TId Id);
    }
}

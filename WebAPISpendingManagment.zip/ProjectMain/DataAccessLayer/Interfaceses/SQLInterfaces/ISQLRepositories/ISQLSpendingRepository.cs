﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Enteties;

namespace DataAccessLayer.Interfaceses.SQLInterfaces.ISQLRepositories
{
    public interface ISQLSpendingRepository : IGenericRepository<Spending, int>
    {
    }
}

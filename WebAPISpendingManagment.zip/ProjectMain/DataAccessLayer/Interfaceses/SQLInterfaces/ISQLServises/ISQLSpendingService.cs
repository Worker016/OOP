﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Enteties;

namespace DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises
{
    public interface ISQLSpendingService
    {
        int AddSpending(Spending spending);

        void UpdateSpending(Spending spending);

        void DeleteSpending(int Id);
        Spending GetSpendingById(int Id);
        IEnumerable<Spending> GetAllSpending();
    }
}

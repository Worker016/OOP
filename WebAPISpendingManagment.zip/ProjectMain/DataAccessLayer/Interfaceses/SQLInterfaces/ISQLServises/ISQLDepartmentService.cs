﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Enteties;

namespace DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises
{
    public interface ISQLDepartmentService
    {
        int AddDepartment(Department department);
        void UpdateDepartment(Department department);
        void DeleteDepartment(int Id);
        Department GetDepartmentById(int Id);
        IEnumerable<Department> GetAllDepartment();
    }
}

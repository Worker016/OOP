﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace DataAccessLayer.Interfaceses
{
    public interface IConnectionFactory
    {
        IDbConnection GetSqlConnection { get; }
            void SetConnection(string connectionstring);
    }
}

﻿using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLRepositories;

namespace DataAccessLayer.Interfaceses
{
    public interface IUnitOfWork
    {
        ISQLSpendingRepository SQLSpendingRepository { get; }
        ISQLDepartmentRepository SQLDepartmentRepository { get; }
        void Complete();
    }
}

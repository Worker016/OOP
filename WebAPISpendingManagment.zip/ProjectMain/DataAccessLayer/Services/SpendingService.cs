﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises;
using DataAccessLayer.Interfaceses;
using DataAccessLayer.Enteties;

namespace DataAccessLayer.Services
{
    public class SpendingService : ISQLSpendingService
    {
        IUnitOfWork _UnitOfWork;
        public SpendingService(IUnitOfWork unitOfWork)
        {
            _UnitOfWork = unitOfWork;
        }
        public int AddSpending(Spending spending)
        {
            return _UnitOfWork.SQLSpendingRepository.Add(spending);
        }
        public void DeleteSpending(int id)
        {
            _UnitOfWork.SQLSpendingRepository.Delete(id);
        }

        public IEnumerable<Spending> GetAllSpending()
        {
            return _UnitOfWork.SQLSpendingRepository.GetAll();
        }

        public Spending GetSpendingById(int Id)
        {
            return _UnitOfWork.SQLSpendingRepository.Get(Id);
        }

        public void UpdateSpending(Spending spending)
        {
            _UnitOfWork.SQLSpendingRepository.Update(spending);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises;
using DataAccessLayer.Interfaceses;
using DataAccessLayer.Enteties;

namespace DataAccessLayer.Services
{
    public class DepartmentService : ISQLDepartmentService
    {
        IUnitOfWork _UnitOfWork;
        public DepartmentService(IUnitOfWork unitOfWork)
        {
            _UnitOfWork = unitOfWork;
        }
        public int AddDepartment(Department department)
        {
            return _UnitOfWork.SQLDepartmentRepository.Add(department);
        }
        public void DeleteDepartment(int id)
        {
            _UnitOfWork.SQLDepartmentRepository.Delete(id);
        }

        public IEnumerable<Department> GetAllDepartment()
        {
            return _UnitOfWork.SQLDepartmentRepository.GetAll();
        }

        public Department GetDepartmentById(int Id)
        {
            return _UnitOfWork.SQLDepartmentRepository.Get(Id);
        }

        public void UpdateDepartment(Department department)
        {
            _UnitOfWork.SQLDepartmentRepository.Update(department);
        }
    }
}

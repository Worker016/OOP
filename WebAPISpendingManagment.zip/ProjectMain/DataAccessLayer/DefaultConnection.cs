﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccessLayer
{
    public class DefaultConnection
    {
      //  public const string y = "Data Source=DESKTOP-EFKAE6O\\SQLEXPRESS;Initial Catalog=Laba4;Integrated Security=True;Connect Timeout=60; Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"
        public const string x = "Data Source=DESKTOP-EFKAE6O\\SQLEXPRESS;Initial Catalog=Laba4;Integrated Security=True;Connect Timeout=60;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    }
}

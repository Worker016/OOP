﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessLayer.Interfaceses;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLRepositories;
namespace DataAccessLayer.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ISQLSpendingRepository _sqlSpendingRepository;
        private readonly ISQLDepartmentRepository _sqlDepartmentRepository ;
        public UnitOfWork(ISQLSpendingRepository sQLSpendingRepository,
            ISQLDepartmentRepository sQLDepartmentRepository)
        {
            _sqlSpendingRepository = sQLSpendingRepository;
            _sqlDepartmentRepository = sQLDepartmentRepository;
        }
        public ISQLSpendingRepository SQLSpendingRepository
        {
            get
            {
                return _sqlSpendingRepository;
            }
        }
        public ISQLDepartmentRepository SQLDepartmentRepository
        {
            get
            {
                return _sqlDepartmentRepository;
            }
        }
        public void Complete()
        {
            throw new NotImplementedException();
        }
    }
}

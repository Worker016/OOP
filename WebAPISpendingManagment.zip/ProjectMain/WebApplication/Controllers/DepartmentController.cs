﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataAccessLayer.Services;
using Microsoft.AspNetCore.Mvc;
using DataAccessLayer.Enteties;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    public class DepartmentController : Controller
    {
        ISQLDepartmentService _departmentService;
        public DepartmentController(ISQLDepartmentService departmentService)
        {
            _departmentService = departmentService;
        }

        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<Department> Get()
        {
            return _departmentService.GetAllDepartment();
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public Department Get(int id)
        {
            return _departmentService.GetDepartmentById(id);
        }

        // POST api/<controller>
        [HttpPost]
        public int Post([FromBody]Department department)
        {
            return _departmentService.AddDepartment(department);
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]Department department)
        {
            _departmentService.UpdateDepartment(department);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int Id)
        {
            _departmentService.DeleteDepartment(Id);
        }
    }
}

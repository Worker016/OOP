﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataAccessLayer.Services;
using Microsoft.AspNetCore.Mvc;
using DataAccessLayer.Enteties;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    public class SpendingController : Controller
    {
        ISQLSpendingService _spendingService;
        public SpendingController(ISQLSpendingService spendingService)
        {
            _spendingService = spendingService;
        }
        
        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<Spending> Get()
        {
            return _spendingService.GetAllSpending();
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public Spending Get(int id)
        {
            return _spendingService.GetSpendingById(id);
        }

        // POST api/<controller>
        [HttpPost]
        public int Post([FromBody]Spending spending)
        {
           return _spendingService.AddSpending(spending);
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]Spending spending)
        {
            _spendingService.UpdateSpending(spending);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int Id)
        {
             _spendingService.DeleteSpending(Id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using DataAccessLayer.Ifrastructure;
using DataAccessLayer.Interfaceses;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLRepositories;
using DataAccessLayer.Interfaceses.SQLInterfaces.ISQLServises;
using DataAccessLayer.Services;
using DataAccessLayer.UnitOfWork;
using DataAccessLayer.Repositories.SQLRepositories;
using DataAccessLayer.Repositories;

namespace WebApplication
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            #region Repositories
            services.AddTransient<ISQLSpendingRepository, SQLSpendingRepository>();
            services.AddTransient<ISQLDepartmentRepository, SQLDepartmentRepository>();
            #endregion

            #region Services
            services.AddTransient<ISQLSpendingService, SpendingService>();
            services.AddTransient<ISQLDepartmentService, DepartmentService>();
            #endregion

            services.AddTransient<IUnitOfWork, UnitOfWork>();

            services.AddTransient<IConnectionFactory, ConnectionFactory>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
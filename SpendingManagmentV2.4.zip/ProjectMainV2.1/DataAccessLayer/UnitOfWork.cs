﻿using DataAccessLayer.Interfaces;
using DataAccessLayer.Interfaces.RepositoryInterfaces;
using System;

namespace DataAccessLayer
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IEmployeeRepository _employeeRepository;
        public UnitOfWork(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public IEmployeeRepository EmployeeRepository
        {
            get
            {
                return _employeeRepository;
            }
        }
        public void Complete()
        {
            throw new NotImplementedException();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BuisnessLogicLayer.DTO;
using BuisnessLogicLayer.Interfaces;
using DataAccessLayer.Entities;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProjectMainV2._1.Controllers
{
    [Route("api/[controller]")]
    public class EmployeeController : Controller
    {
        IEmployeeService _EmployeeService;
        public EmployeeController(IEmployeeService EmployeeService)
        {
            _EmployeeService = EmployeeService;
        }
        // GET: api/<controller>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeDTO>>> Get()
        {
            //status codes
            try
            {
                return Ok(await _EmployeeService.GetAllEmployee());
            }
            catch
            {
                return NotFound();
            }

        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public async Task<EmployeeDTO> Get(int id)
        {
            return await _EmployeeService.GetEmployeeById(id);
        }
        // POST api/<controller>
        [HttpPost]
        public async Task Post([FromBody]EmployeeDTO employee)
        {
            await _EmployeeService.AddEmployee(employee);
        }

        // PUT api/<controller>/5
        [HttpPut]
        public async Task Put([FromBody]EmployeeDTO employee)
        {
           await _EmployeeService.UpdateEmployee(employee);
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            await _EmployeeService.DeleteEmployee(id);
        }
    }
}

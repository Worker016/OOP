﻿using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BuisnessLogicLayer.Interfaces
{
    public interface ISpendingService
    {
        int AddSpending(Spending spending);
        void UpdateSpending(Spending spending);
        void DeleteSpending(int Id);
        Spending GetSpendingById(int Id);
        IEnumerable<Spending> GetAllSpending();
    }
}

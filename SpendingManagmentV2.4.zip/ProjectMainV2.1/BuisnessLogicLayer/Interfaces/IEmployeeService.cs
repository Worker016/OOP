﻿using BuisnessLogicLayer.DTO;
using DataAccessLayer.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessLogicLayer.Interfaces
{
    public interface IEmployeeService
    {
        Task AddEmployee(EmployeeDTO spending);
        Task UpdateEmployee(EmployeeDTO spending);
        Task DeleteEmployee(int Id);
        Task<EmployeeDTO> GetEmployeeById(int Id);
        Task<IEnumerable<EmployeeDTO>> GetAllEmployee();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuisnessLogicLayer.Services
{
    class SpendingService
    {
    }
}

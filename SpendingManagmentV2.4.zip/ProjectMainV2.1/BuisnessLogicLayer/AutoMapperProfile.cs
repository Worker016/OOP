﻿using AutoMapper;
using BuisnessLogicLayer.DTO;
using DataAccessLayer.Entities;
using System;

namespace BuisnessLogicLayer
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Employee, EmployeeDTO>().ReverseMap();// mapping from employee to employeeDTO
        }
    }
}

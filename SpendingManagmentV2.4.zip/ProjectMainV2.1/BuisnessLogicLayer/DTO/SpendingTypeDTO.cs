﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuisnessLogicLayer.DTO
{
    class SpendingTypeDTO
    {
        public int Id { get; set; }
        public string Spending_name { get; set; }
        public string Description { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuisnessLogicLayer.DTO
{
    class DepartmentDTO
    {
        public int Id { get; set; }
        public string Depart_name { get; set; }
        public int Employee_count { get; set; }
    }
}

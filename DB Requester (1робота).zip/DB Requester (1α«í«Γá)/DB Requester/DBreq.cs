﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Data.Sql;
using System.Data.SqlClient;
//using System.Data.SqlTypes;
using System.Data;
namespace DB_Requester
{
    public class DBRequest
    {
        private SqlConnection DBCon = new SqlConnection();

        public void ConnectTo(string DataSource, string InitialCatalog)
        {
            string connectionString = $@"Data Source={DataSource};Initial Catalog={InitialCatalog};Integrated Security=True";
            DBCon.ConnectionString = connectionString;                
            
            try
            {
                DBCon.Open();
            }
            catch (Exception e)
            { throw e; }
        }

        public void Disconnect()
        {
            try
            {
                if (DBCon.State == ConnectionState.Open)
                    DBCon.Close();
            }
            catch
            { }
        }
        ~DBRequest()
        {
            Disconnect();
        }

        public string GetTableFields(string TableName)//no
        {
            if (DBCon.State == System.Data.ConnectionState.Open)
            {
                System.Data.DataTable CurTable = new System.Data.DataTable("ConnectedTab");
                SqlDataAdapter DBAdapt;
                try
                { DBAdapt = new SqlDataAdapter("SELECT * FROM " + TableName, DBCon);
                  DBAdapt.Fill(CurTable);
                }
                catch (Exception e)
                { throw e; }
                string ResStr = "";
                int ColCount = CurTable.Columns.Count;
                for (int i = 0; i < ColCount; i++)
                { string StrCon = ", ";
                    if (i == ColCount - 1) StrCon = ";";
                    ResStr += CurTable.Columns[i].ColumnName + "[" + CurTable.Columns[i].DataType.Name + "]" + StrCon;
                } return ResStr; }
            else return null;
        }

        public System.Data.DataTable SQLRequest(string RequestStr)//no
        {
            if (DBCon.State == System.Data.ConnectionState.Open)
            {
                System.Data.DataTable ResultTab = new System.Data.DataTable("SQLresult");
                SqlDataAdapter DBAdapt;
                try
                {
                    DBAdapt = new SqlDataAdapter(RequestStr, DBCon);
                    DBAdapt.Fill(ResultTab);
                }
                catch (Exception e)
                { throw e; }
                return ResultTab;
            }
            else
                return null;
        }
    }
}

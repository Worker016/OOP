﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace DataAccessLayer.Entities
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {
            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)//fluent validation
        {
            base.OnModelCreating(modelBuilder);
            #region Spending
            modelBuilder.Entity<Spending>()
                .HasKey(x => x.Id);
            modelBuilder.Entity<Spending>()
                .Property(p => p.Id_Dep)
                .IsRequired();
            modelBuilder.Entity<Spending>()
                .Property(p => p.Id_Spend_type)
                .IsRequired();
            modelBuilder.Entity<Spending>()
                .Property(p => p.Summa)
                .IsRequired();
            modelBuilder.Entity<Spending>()
                .HasOne(q => q.Spending_type)
                .WithMany(g => g.Spendings)
                .HasForeignKey(x => x.Id_Spend_type);
            modelBuilder.Entity<Spending>()
                .HasOne(q => q.Department)
                .WithMany(g => g.Spendings)
                .HasForeignKey(x => x.Id_Dep);
            //modelBuilder.Entity<Spending>()
            //    .Property(p => p.DateT)
            //    .HasDefaultValueSql("getdate()");
            #endregion

            #region Department
            modelBuilder.Entity<Department>()
                .HasKey(x => x.Id);
            modelBuilder.Entity<Department>()
                .Property(p => p.Depart_name)
                .HasMaxLength(45)
                .IsRequired();
            modelBuilder.Entity<Department>()
                .Property(p => p.Employee_count)
                .IsRequired();
            #endregion

            #region Spending_type
            modelBuilder.Entity<Spending_type>()
                .HasKey(x => x.Id);
            modelBuilder.Entity<Spending_type>()
                .Property(p => p.Spending_name)
                .HasMaxLength(45)
                .IsRequired();
            #endregion

            #region Limit_Value
            modelBuilder.Entity<Limit_value>()
                .HasKey(x => x.Id);
            modelBuilder.Entity<Limit_value>()
                .Property(p => p.Id_Dep)
                .IsRequired();
            modelBuilder.Entity<Limit_value>()
                .Property(p => p.Id_Spend_type)
                .IsRequired();
            modelBuilder.Entity<Limit_value>()
                .Property(p => p.Limit_value_in_order)
                .IsRequired();

            modelBuilder.Entity<Limit_value>()
                .HasOne(q => q.Spending_type)
                .WithMany(g => g.Limit_Values)
                .HasForeignKey(x => x.Id_Spend_type);
            modelBuilder.Entity<Limit_value>()
                .HasOne(q => q.Department)
                .WithMany(g => g.Limit_Values)
                .HasForeignKey(x => x.Id_Dep);
            #endregion

            #region Employee
            modelBuilder.Entity<Employee>()
                .HasKey(x => x.Id);
            modelBuilder.Entity<Employee>()
                .Property(p => p.Name)
                .HasMaxLength(45)
                .IsRequired();
            modelBuilder.Entity<Employee>()
                .Property(p => p.SurName)
                .HasMaxLength(45)
                .IsRequired();
            modelBuilder.Entity<Employee>()
                .Property(p => p.LastName)
                .HasMaxLength(45)
                .IsRequired();
            modelBuilder.Entity<Employee>()
                .Property(p => p.Id_Dep)
                .IsRequired();
            modelBuilder.Entity<Employee>()
                .Property(p => p.Salary)
                .IsRequired();

            modelBuilder.Entity<Employee>()
                .HasOne(s => s.Department)
                .WithMany(g => g.Employees)
                .HasForeignKey(s => s.Id_Dep);
            #endregion
        }
        public DbSet<Spending> Spendings { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Spending_type> Spending_Types { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Limit_value> limit_Values { get; set; }
    }
}
